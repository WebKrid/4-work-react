import React from "react";
const pust => {
 return ( 
  Тут Нечего не найденно
   );
};

export default pusto;