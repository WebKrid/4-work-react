import React from "react";
import {NavLink, Outlet} from "react-router-dom";

const Layout = () => {
   return (
      <>
 <header style={{ width: '100%', height: 100, background: 'red'}}>
      <NavLink  style={({inActive}) => ({color: inActive ? 'red' : 'black'})} to='/'>Home</NavLink>
      <NavLink href='/blog'>Blog</NavLink>
      <NavLink href='/about'>About</NavLink>
     </header>
     <main>
      <Outlet />
     </main>
      </>
   );
};

export default Layout;

// Мы говорим что-бы у нас Объект остался в main (контентноя часть)