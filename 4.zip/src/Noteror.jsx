import React from "react";

const Noteror = () => {
   return (
      <div>
         Страница не найдена 
      </div>
   );
};

export default Noteror;