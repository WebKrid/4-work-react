import './App.css';
import { Routes, Route, NavLink } from "react-router-dom";
import Home from "./Home";
import Blog from "./blog";
import pusto from './pusto';
import profily from './profily';
import Noteror from './Noteror';
function App() {
   return (
           <Route path='/vk.com' element={<blog />} />
           <Route path='/https://github.com/WebKrid' element={<profily />} />
           <Route path='**'element={<Noteror />}/>

   );
}

   export default App;
// описание 1*25*40/1*26*20