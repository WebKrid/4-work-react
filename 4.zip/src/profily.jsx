import React from "react";

const blog = ({children}) => {
 return ( 
  <button>
   {children}
  </button>
   );
};

export default profily;